<?php
session_start();
date_default_timezone_set('Asia/Kolkata');
include('includes/config.php');
if(isset($_POST['submit']))
{
$prno=$_POST['prno'];
$name=$_POST['name'];
$email=$_POST['email'];
$course=$_POST['course'];
$dept=$_POST['dept'];
$addr=$_POST['addr'];
$hostel=$_POST['hostel'];
$challanNo=$_POST['challanNo'];
$amount=$_POST['amount'];
$bankName=$_POST['bankName'];
$branch=$_POST['branch'];
$ifsc=$_POST['ifsc'];
$micr=$_POST['micr'];
$accNo=$_POST['accNo'];
$accHldrName=$_POST['accHldrName'];
$udate = date('d-m-Y h:i:s', time());
$query="insert into  applyrefund(PrNo,name,email,course,dept,addr,stayedFrom,stayedTill,hostel,challanNo,challanDate,amount,bankName,branch,ifsc,micr,accNo,accHldrName) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
$stmt = $mysqli->prepare($query);
$rc=$stmt->bind_param('sssssssssisisssiis',$prno,$name,$email,$course,$dept,$addr,$stayedFrom,$stayedTill,$hostel,$challanNo,$challanDate,$amount,$bankName,$branch,$ifsc,$micr,$accNo,$accHldrName);
$stmt->execute();
echo"<script>alert('Refund form successfully submitted. After verification amount will be credited within a week.');
		window.location.href = 'dashboard.php'</script>";
}
?>

<!doctype html>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	<title>Refund Application</title>
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">>
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<link rel="stylesheet" href="css/fileinput.min.css">
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<link rel="stylesheet" href="css/menu.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="css/style.css">
<script type="text/javascript" src="js/jquery-1.11.3-jquery.min.js"></script>
<script type="text/javascript" src="js/validation.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
<script type="text/javascript">
function valid()
{
	return true;
}
</script>

</head>
<body>
	<?php include('includes/header1.php');?>
	<div class="ts-main-content">
		<?php include('includes/sidebar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">
					
						<h2 class="page-title">Refund Application</h2>

						<div class="row">
							<div class="col-md-12">
								<div class="panel panel-primary">
									<div class="panel-heading">Fill all Info</div>
									<div class="panel-body">
			<form method="post" action="" name="registration" class="form-horizontal" onSubmit="return valid();">
																		
<div class="form-group">
<label class="col-sm-2 control-label"> Date : </label>
<div class="col-sm-8">
<input type="text" name="applyDate" id="applyDate" class="form-control" value='<?php echo date('d-m-Y');?>' disabled>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label"> PR NO : </label>
<div class="col-sm-8">
<input type="text" name="prno" id="prno"  class="form-control" required="required" >
</div>
</div>


<div class="form-group">
<label class="col-sm-2 control-label">Full Name : </label>
<div class="col-sm-8">
<input type="text" name="name" id="name"  class="form-control" required="required" >
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Email id : </label>
<div class="col-sm-8" id="emaildiv">
<input type="email" name="email" id="email"  class="form-control" onBlur="checkAvailability()" required="required">
<span id="user-availability-status" style="font-size:12px; color:red;"></span>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Course : </label>
<div class="col-sm-8">
<input type="text" name="course" id="course"  class="form-control" required="required">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Department : </label>
<div class="col-sm-8">
<input type="text" name="dept" id="dept"  class="form-control" required="required">
</div>
</div>					

<div class="form-group">
<label class="col-sm-2 control-label">Permanent Address : </label>
<div class="col-sm-8">
<input type="text" name="addr" id="addr"  class="form-control" required="required">
</div>
</div>

<br>
<h3>Hostel Details</h3><br>
<div class="form-group">
<label class="col-sm-2 control-label">Hostel Name : </label>
<div class="col-sm-8">
<select name="hostel" id="hostel" class="form-control" required="required">
<option>Select</option>
<option>Mens Hostel 1</option>
<option>Mens Hostel 2</option>
<option>Mens Hostel 3</option>
<option>Womens Hostel 1</option>
<option>Womens Hostel 2</option>
<option>Womens Hostel 3</option>
<option>Womens Hostel 4</option>
</select>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Stayed From : </label>
<div class="col-sm-8">
<input type="date" name="applyDate" id="applyDate" class="form-control">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Stayed Till : </label>
<div class="col-sm-8">
<input type="date" name="applyDate" id="applyDate" class="form-control">
</div>
</div>

<br>
<h3>Details of amount paid</h3><br>
<div class="form-group">
<label class="col-sm-2 control-label">Challan No. : </label>
<div class="col-sm-8">
<input type="number" name="challanNo" id="challanNo"  class="form-control" required="required">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Challan Date : </label>
<div class="col-sm-8">
<input type="date" name="applyDate" id="applyDate" class="form-control">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Amount : </label>
<div class="col-sm-8">
<input type="number" name="amount" id="amount"  class="form-control" required="required">
</div>
</div>

<br>
<h3>Bank details to refund the amount</h3><br>
<div class="form-group">
<label class="col-sm-2 control-label">Bank Name : </label>
<div class="col-sm-8">
<input type="text" name="bankName" id="bankName"  class="form-control" required="required">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Branch : </label>
<div class="col-sm-8">
<input type="text" name="branch" id="branch"  class="form-control" required="required">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">IFSC Code : </label>
<div class="col-sm-8">
<input type="text" name="ifsc" id="ifsc"  class="form-control" required="required">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">MICR Code : </label>
<div class="col-sm-8">
<input type="number" name="micr" id="micr"  class="form-control" required="required">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Account No. : </label>
<div class="col-sm-8">
<input type="number" name="accNo" id="accNo"  class="form-control" required="required">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Account Holder Name : </label>
<div class="col-sm-8">
<input type="text" name="accHldrName" id="accHldrName"  class="form-control" required="required">
</div>
</div>

<div class="col-sm-6 col-sm-offset-4" id="submitdiv">
<button class="btn btn-default" type="submit">Cancel</button>
<input type="submit" id="submit" name="submit" Value="Submit" disabled="disabled" class="btn btn-primary">
</div>

</form>
<script>
var toValidate = jQuery('#prno, #email, #stayedFrom, #stayedTill, #hostel, #challanNo, #challanDate, #amount, #bankName, #branch, #ifsc, #micr, #accNo, #accHldrName'),
    valid = false;
    toValidate.keyup(function () {
    if (jQuery(this).val().length > 0) {
        jQuery(this).data('valid', true);
    } else {
        jQuery(this).data('valid', false);
    }
    toValidate.each(function () {
        if (jQuery(this).data('valid') == true) {
            valid = true;
        } else {
            valid = false;
        }
    });
    if (valid === true) {
        jQuery("#submit").prop('disabled', false);
    } else {
        jQuery("#submit").prop('disabled', true);
    }
});
</script>

									</div>
									</div>
								</div>
							</div>
						</div>
							</div>
						</div>
					</div>
				</div> 	
			</div>
		</div>
	</div>
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>
</body>

	
<script>
function checkAvailability() {

$("#loaderIcon").show();
jQuery.ajax({
url: "check_exists.php",
data:'emailid='+$("#email").val(),
type: "POST",
success:function(data){
if (data == 0) {
    $("#email").css("border","2px solid red");
    $("#user-availability-status").text(' Email not registered with hostel');
      setTimeout(function () {
        alert('Kindly enter registered email id');
        $('#emaildiv').load('apply-refund.php #email');
      }, 1200);        
}

$("#loaderIcon").hide();
},
error:function ()
{
event.preventDefault();
alert('error');
}
});
}
</script>

</html