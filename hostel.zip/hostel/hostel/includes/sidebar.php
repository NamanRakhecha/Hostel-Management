



<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
							<div class="dropdown">
  <button class="dropbtn"><span class="glyphicon glyphicon-menu-hamburger  "></span> Menu</button>
  <div class="dropdown-content">
    		<?PHP if(isset($_SESSION['id']))
				{ ?>
					<li><a href="dashboard.php"><i class="fa fa-desktop"></i>Dashboard</a></li>
					<li><a href="my-profile.php"><i class="fa fa-user"></i> My Profile</a></li>
<li><a href="change-password.php"><i class="fa fa-files-o"></i>Change Password</a></li>
<li><a href="book-hostel.php"><i class="fa fa-file-o"></i>Book Hostel</a></li>
<li><a href="room-details.php"><i class="fa fa-file-o"></i>Room Details</a></li>
<li><a href="gym-register.php"><i class="fa fa-file-o"></i>Register for Gym</a></li>
<li><a href="complaints-register.php"><i class="fa fa-file-o"></i>Register Complaints</a></li>
<li><a href="apply-refund.php"><i class="fa fa-file-o"></i>Apply for refund</a></li>
<li><a href="access-log.php"><i class="fa fa-file-o"></i>Access log</a></li>
<?php } else { ?>
				
				<li><a href="registration.php"><i class="fa fa-files-o"></i> User Registration</a></li>
				<li><a href="index.php"><i class="fa fa-users"></i> User Login</a></li>
				<li><a href="admin"><i class="fa fa-user"></i> Admin Login</a></li>
				<li><a href="feedback/formpage.php" target="_blank"><i class=""></i> Feedback form</a></li>		
				<?php } ?>

  </div>
</div>



			</ul>
		</nav>